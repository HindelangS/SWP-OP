
public class BlutdruckMessen extends Component{

	@Override
	public void operation() {
		System.out.println("Messe Blutdruck");
	}

	@Override
	public int getPrize() {
		return 50;
	}

}
