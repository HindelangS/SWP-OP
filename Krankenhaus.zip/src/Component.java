
public abstract class Component {
	abstract public void operation();
	abstract public int getPrize();
}
