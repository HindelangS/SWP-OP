
public class FieberMessen extends Component{

	@Override
	public void operation() {
		System.out.println("Messe Fieber");
	}

	@Override
	public int getPrize() {
		return 300;
	}

}
